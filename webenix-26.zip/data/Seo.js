export const data = {
    home: {
        title: "Hire Dedicated Developer | Web & Mobile App Development Company",
        description: "",
        keyword: "Hire Dedicated Developers, Hire Remote Developers, Hire Remote Developers India, Hire Remote Software Developer,"
    },
    about: {
        title: "About Us - Webenix Technologies & Solutions",
        description: "",
        keyword: "About Us Webenix, Webenix Technologies, Webenix Solutions"
    },
    infrastructure: {
        title: "Webenix Infrastructure | Creative Working Environment",
        description: "",
        keyword: "Webenix Technology Infrastructure, Webenix Technology Working Environment,"
    },
    engagementmodels: {
        title: "Our Engagement Model | Hire Professional Developer | Webemox Technologies",
        description: "",
        keyword: "Engagement Model, Hire Professional Developer"
    },
    career: {
        title: "Jobs & Career Opportunity at Webenix",
        description: "",
        keyword: "Jobs Opportunity, Career Opportunity, Webenix Technologies"
    },
    confidentiality: {
        title: "Confidentiality | Code Ownership & Non Disclosure | Webenix Technologies",
        description: "",
        keyword: "Confidentiality, Code Ownership, Non Disclosure"
    },
    contact: {
        title: "",
        description: "",
        keyword: ""
    },
    graphicsdesign: {
        title: "",
        description: "",
        keyword: ""
    },
    webdesign: {
        title: "",
        description: "",
        keyword: ""
    },
    uiux: {
        title: "",
        description: "",
        keyword: ""
    },
    webdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    frontenddevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    backenddevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    ecommercedevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    cmsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    mobileappdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    mvpdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    seo: {
        title: "",
        description: "",
        keyword: ""
    },
    smo: {
        title: "",
        description: "",
        keyword: ""
    },
    ppc: {
        title: "",
        description: "",
        keyword: ""
    },
    itconsulting: {
        title: "",
        description: "",
        keyword: ""
    },
    startupconsulting: {
        title: "",
        description: "",
        keyword: ""
    },
    nextjsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    pgi: {
        title: "",
        description: "",
        keyword: ""
    },
    shippingintegration: {
        title: "",
        description: "",
        keyword: ""
    },
    smi: {
        title: "",
        description: "",
        keyword: ""
    },
    tpai: {
        title: "",
        description: "",
        keyword: ""
    },
    supportandmaintenance: {
        title: "",
        description: "",
        keyword: ""
    },
    phpdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    laraveldevelopment: {
        title: "aa",
        description: "",
        keyword: ""
    },
    codeigniterdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    wordpressdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    shopifydevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    webflowdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    hubspotdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    reactjsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    nodejsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    angularjsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    expressjsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    androidappsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    iosappsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    ipadappsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    flutterappsdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    reactnativedevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    ionicdevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    progressivedevelopment: {
        title: "",
        description: "",
        keyword: ""
    },
    designprototype: {
        title: "",
        description: "",
        keyword: ""
    },
    mobileappdesign: {
        title: "",
        description: "",
        keyword: ""
    },
    psdtohtml: {
        title: "",
        description: "",
        keyword: ""
    },
    responsivewebdesign: {
        title: "",
        description: "",
        keyword: ""
    },
    hiregraphicsdesigner: {
        title: "",
        description: "",
        keyword: ""
    },
    hirewebdesigner: {
        title: "",
        description: "",
        keyword: ""
    },
    hireuiuxdesigner: {
        title: "",
        description: "",
        keyword: ""
    },
    hirephpdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hiredotnetdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirlaraveldeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hircodeigniterdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirewordpressdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirshopifyrdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirewebflowdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirehubspotdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireandroiddeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireiosdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireflutterdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireionicdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirereactnativedeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirereactjsdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirenodejsdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireexpressdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hirenextjsdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    hireangularjsdeveloper: {
        title: "",
        description: "",
        keyword: ""
    },
    blog: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog1: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog2: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog3: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog4: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog5: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog6: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog7: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog8: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog9: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog10: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog11: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog12: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog13: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog14: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog15: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog16: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog17: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog18: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog19: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog20: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog21: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog22: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog23: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog24: {
        title: "",
        description: "",
        keyword: ""
    },
    singleblog25: {
        title: "",
        description: "",
        keyword: ""
    },
    work: {
        title: "",
        description: "",
        keyword: ""
    },
    usapipelining: {
        title: "",
        description: "",
        keyword: ""
    },
    southerntradelines: {
        title: "",
        description: "",
        keyword: ""
    },
    theblossomacademy: {
        title: "",
        description: "",
        keyword: ""
    },
    lifecoachakhan: {
        title: "",
        description: "",
        keyword: ""
    },
    ellemar: {
        title: "",
        description: "",
        keyword: ""
    },
    diningedge: {
        title: "",
        description: "",
        keyword: ""
    },
    balderasconstruction: {
        title: "",
        description: "",
        keyword: ""
    },
    superstarscamp: {
        title: "",
        description: "",
        keyword: ""
    }
    
};