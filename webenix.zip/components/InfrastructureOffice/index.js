import React from 'react';
import Link from "next/link";
import Image from "next/image";
import { Container, Row, Col } from "react-bootstrap";
import * as s from "../../styles/components/InfrastructureOffice/InfrastructureOffice.style";

 
const InfrastructureOffice = (props) => {
  return (
    <> 
     <s.SectionIntroWrapper className="introuction-section">
          <s.LeftRightPart className="leftRightPart">
            <div className="right-slant">
              <div className="anmtn-element in-view">
                <div className="animated-cuts-right">
                  <div className="right-bg"></div>
                </div>
              </div>
            </div>
            <Container>
                <Row>
                  <Col md={7} lg={6}>
                    <s.SectionTagline>
                      <span className='before-dash'>Take a look at</span>
                      <h2>Our Office</h2>
                    </s.SectionTagline>
                    <div className='boxesPart'>
                      <div className="multiple-infraplates">
                          <div className="infraplates ROSIEBG">
                            <div>
                              <p>Area</p>
                              <h6>1200 sqft.</h6>
                            </div>
                          </div>
                          <div className="infraplates LAVENDERTONICBG">
                            <div>
                              <p>Strength</p>
                              <h6>25+</h6>
                            </div>
                          </div>
                            <div className="infraplates NORTHRENDBG">
                              <div>
                                <p>Capacity</p>
                                <h6>50+</h6>
                              </div>
                            </div>
                        </div>
                        <ul>
                          <li>Over 1,200 Sq. Ft of state-of-the-art development center</li>
                          <li>Currently housing team of 25+ CMARIans</li>
                          <li>Expandable capacity of 50+ employees</li>
                          <li>Open seating for cross team collaboration</li>
                          <li>Green energy conservation systems</li>
                          <li>24 x 7 Power through Torrent (private electric provider)</li>
                          <li>Backup Power via UPS and Generators</li>
                          <li>2000 Sq. Ft of recreation and gaming area</li>
                          <li>Additional 10,000 Sq. Ft+ of scalable office infrastructure</li>
                        </ul>
                    </div>
                  </Col>
                  <Col md={5} lg={6} className="text-center">
                    <div className="rellimage neverstoplearning"></div>
                  </Col>
                </Row>
            </Container>
          </s.LeftRightPart>
          <s.LeftRightPart className="leftRightPart">
            <div className="left-slant">
              <div className="anmtn-element in-view">
                <div className="animated-cuts-right">
                  <div className="right-bg"></div>
                </div>
              </div>
            </div>
            <Container>
                <Row>
                  <Col md={5} lg={6} className="text-center">
                    <div className="rellimage neverstoplearning mt-0 ms-0"></div>
                  </Col>
                  <Col md={7} lg={6}>
                    <s.SectionTagline>
                      <span className='before-dash'>Take a look at</span>
                      <h2>Security & Surveillance</h2>
                    </s.SectionTagline>
                    <div className='boxesPart'>
                      <div className="multiple-infraplates">
                          <div className="infraplates MINIONYELLOWBG">
                            <div>
                              <ul>
                                <li>High Definition CCTV Surveillance</li>
                                <li>Biometric Access control (COSEC PATH DCFx)</li>
                                <li>Certified Security Personnel</li>
                                <li>SVN Implementation</li>
                                <li>Disaster recovery provision</li>
                                <li>Advanced software for monitoring servers</li>
                                <li>RAID (redundant array of independent disks)</li>
                                <li>NagiOS to monitor servers and applications</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                    </div>
                  </Col>
                </Row>
            </Container>
          </s.LeftRightPart>
      </s.SectionIntroWrapper>
    </>
  );
};

export default InfrastructureOffice