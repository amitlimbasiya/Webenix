import React from 'react'
import PageBanner from '../components/PageBanner';
import SectionIntro from '../components/CareerPage/SectionIntro';
import Perks from '../components/CareerPage/Perks';

const CAREER = () => {
  return (
    <>
      <PageBanner 
        PageBannerClass="pagebanner-section top-right darkGreenNoice"
        PageBannerImgClass="pagebannerimg-col at-right-bottom" 
        PageBannerTitle="We Discover And Hire The Cream Of The Crop"
        PageBannerBtnText="VIEW OPENINGS"
        PageBannerBtnLink=""
        PageBannerImageWidth="557px"
        PageBannerImageHeight="298px"
        PageBannerImage="/images/career/career-banner-icon.svg"/>
      <SectionIntro/>
      <Perks/>
      </>
  )
}

export default CAREER