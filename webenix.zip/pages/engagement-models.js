import React from 'react';
import { Container } from "react-bootstrap";
import EngagementModel from '../components/EngagementModel';
import PageBanner2 from '../components/PageBanner2';
import SectionIntro from '../components/SectionIntro';
import SteptoEngage from '../components/SteptoEngage';
import TechnologyStack from '../components/TechnologyStack';
import * as s from "../styles/components/EngagementModel/EngagementModel.style";

const EngagementModels = () => {
  return (
    <>
      <PageBanner2 PageBannerTitle="Our Engagement Models"/>
      <SectionIntro 
        IntroSubTitle="Work Offshore to"
        IntroMainTitle="Find Everything Under One Roof At WEBENIX."
        IntroContent='
          <h3>Lorem Ipsum</h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
          <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
      '/>
      <s.SectionTagline>
        <Container>
          <span className="before-dash">Take a look at</span>
          <h2>Engagement Models</h2>
        </Container>
      </s.SectionTagline>
      <EngagementModel 
        EngagementClass="engagementmodel-row"
        EngagementModelImage="/images/hybrid-model.png"     
        EngagementModelImageWidth="705"
        EngagementModelImageHeight="410"  
        EngagementMainTitle="Direct Approach"    
        EngagementModelIcon="/images/hybrid-model-icon.svg"
        EngagementModelIconWidth="100"
        EngagementModelIconHeight="100"
        EngagementModelName="Hybrid Model"
        EngagementContent='
          <p>"Hybrid model as the name suggests is a “hybrid” approach which provides local project management and offshore development. This is mostly preferred by enterprise projects."</p>
          <ul>
            <li>Communication in your timezone locally</li>
            <li>Zero Communication Gap</li>
            <li>Cost Effective offshore development</li>
            <li>Flexibility to scale team as needed</li>
            <li>Greater Operational Benefits</li>
            <li>Increased Quality Control</li>
          </ul>
      '/>

      <EngagementModel 
        EngagementClass="engagementmodel-row engagementmodel-alt engagement-green-titlebg"
        EngagementModelImage="/images/flexibility.png"     
        EngagementModelImageWidth="854"
        EngagementModelImageHeight="548"  
        EngagementMainTitle="Flexibility"    
        EngagementModelIcon="/images/flexibility-icon.svg"
        EngagementModelIconWidth="100"
        EngagementModelIconHeight="100"
        EngagementModelName="Time and Material"
        EngagementContent='
          <p>"Time and Material model is basically when you hire skilled experts – Designers, Developers or Quality Analysts on hourly, monthly or long term contracts. This is suited for all types of project small, mid or enterprise."</p>
          <ul>
            <li>Flexibility to scale up or down team as per business needs</li>
            <li>Work can be done on single or multiple projects</li>
            <li>Complete control over costing</li>
            <li>SCRUM based execution. Daily communication & reporting.</li>
            <li>Most suitable for changing requirements</li>
            <li>Dedicated Developer on Hire working ONLY for you</li>
          </ul>
      '/>

      <EngagementModel 
        EngagementClass="engagementmodel-row engagement-orange-titlebg"
        EngagementModelImage="/images/dedicated-developer.png"     
        EngagementModelImageWidth="705"
        EngagementModelImageHeight="410"  
        EngagementMainTitle="Turnkey Solution"
        EngagementModelIcon="/images/fixed-cost-icon.svg"
        EngagementModelIconWidth="100"
        EngagementModelIconHeight="100"
        EngagementModelName="Fixed Cost Model"
        EngagementContent='
          <p>"Fixed cost model is when project requirements and specifications are well defined based on which a fixed time and cost estimation is provided. This is mostly suited for small to midsize projects."</p>
          <ul>
            <li>Suited when project scope is well defined</li>
            <li>Entire Team allocation depending on size of project.</li>
            <li>Milestone wise payment structure</li>
            <li>Can implement Addon or Change Request Items</li>
            <li>End to End Service Delivery on fixed cost basis</li>
          </ul>
      '/>

      <EngagementModel 
        EngagementClass="engagementmodel-row engagementmodel-alt engagement-pink-titlebg mb-0"
        EngagementModelImage="/images/offshore-development-model.png"     
        EngagementModelImageWidth="872"
        EngagementModelImageHeight="568"  
        EngagementMainTitle="Cost-effective"    
        EngagementModelIcon="/images/cost-effective-icon.svg"
        EngagementModelIconWidth="100"
        EngagementModelIconHeight="100"
        EngagementModelName="Offshore Development Model"
        EngagementContent='
          <p>"Offshore Development Centers (ODCs) are composed of highly skilled Technical experts from CMARIX in collaboration with your team. Our in house team functions as an extended part of your own team."</p>
          <ul>
            <li>Highest cost advantages and ROI of the investment</li>
            <li>Great collaboration of two efficient teams</li>
            <li>Expansion of technical vertices to find best solutions</li>
            <li>Added infrastructure for better quality assurance</li>
            <li>Shared responsibility to minimize risk</li>
            <li>Complete transparency and security</li>
          </ul>
      '/>
      <TechnologyStack/>
      <SteptoEngage/>
    </>
  )
}

export default EngagementModels