import styled, { css } from "styled-components";
import { mediaQueries, mediaQueriesmin } from "../../../utils/mediaQuery";

export const PageBannerWrapper  = styled.div` 
    background-color: rgba(218,218,242,0.75);
    position: relative;
    overflow: hidden;

    .container{      
        position: relative;
        padding-left: 30px;
        padding-right: 30px;
        max-width: 1430px;

        
        ${mediaQueries("llg")`
            padding-left: 30px;
            padding-right: 30px;
        `}       
    } 

    .row{
        align-items: center;
        padding-top: 100px;
        min-height: 600px;


        ${mediaQueries("llg")` 
           min-height: auto;
           padding-top: 120px;
           padding-bottom: 100px;
        `} 

        ${mediaQueries("mobile")`          
           padding-top: 100px;
           padding-bottom: 60px;
        `} 

    }

    ${mediaQueries("xxl")`
        
        .pagebannerimg-col{
            position: relative;
        }

    `}   
    
    ${mediaQueries("llg")` 
        .pagebannercontent-col{
            width: 100%; 
        }
        .pagebannerimg-col{
            display: none;
        }      
    `} 

    &.bg_lightgreen{
        background: rgb(210, 245, 238);
    }
    &.bg_lightgreen.pagebanner-shape::before{
        
    }
    &.pagebanner-shape::before{
        content: '';
        position: absolute;
        bottom:0px;
        left:0px;
        background-color: rgb(188, 243, 232);
        -webkit-mask-image: url('images/banner-shape-before.svg');
        mask-image: url('images/banner-shape-before.svg') no-repeat;
        background-repeat:no-repeat;
        height: 328px;
        width: 710px;
        opacity: 1;

        ${mediaQueries("mobile")`
            height: 200px;
            background-size: contain;
        `}
    }

    &.pagebanner-align-center .row{
        align-items: center;
    }
    &.pagebanner-align-center .pagebanner-imgpart{
        justify-content: center;
    }
    .at-right-bottom{
        position: absolute;
        bottom: -7px;
        right: 0;
    }

`;

export const PageBannerContentPart  = styled.div` 
    padding-right: 100px;
    padding-bottom: 50px;
    
    ${mediaQueries("xll")`
        padding-right: 0px;
    `}
    ${mediaQueries("llg")`
        padding-bottom: 0px;
    `}
  

    h1{ 
        font-family: 'Montserrat',sans-serif;
        font-weight: 700;
        font-size: 42px;
        letter-spacing: 0.2px;
        color: #000;
        margin-bottom: 20px;

        ${mediaQueries("mobile")` 
            font-size: 32px;
            margin-bottom: 15px;
        `} 
    }


    p{
        font-family: "DINPro-Medium";
        font-size: 22px;
        line-height: 32px;
        color: #000;
        margin: 0px;

        ${mediaQueries("xl")` 
            font-size: 20px;
            line-height: 34px;
        `}
        ${mediaQueries("mobile")` 
            font-size: 18px;
            line-height: 28px;
        `}
    }
     
    .btn-default{
        margin-top: 25px; 
    }

    ${mediaQueries("mobile")` 
       text-align: center;
        padding-left: 0;
        padding-right: 0; 
    `}
`;

export const PageBannerImagePart  = styled.div` 
    display: flex;   
`;


export const IntroductionWrapper  = styled.div`     
    padding-top: 120px;
    padding-bottom: 250px;   
    
`;
