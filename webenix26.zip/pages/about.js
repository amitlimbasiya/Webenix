import React from 'react'
import PageBanner from '../components/PageBanner';
import SectionIntro from '../components/SectionIntro';
import MoreResource from '../components/AboutPage/MoreResource';
import WhyUs from '../components/AboutPage/WhyUs';
import HireServies from '../components/HireServices';
import Blog from '../components/Blog';

const About = () => {
  return (
    <>
      <PageBanner 
        PageBannerClass="pagebanner-section"
        PageBannerImgClass="pagebannerimg-col at-right-bottom" 
        PageBannerTitle="Meet"
        PageBannerGreenTitle="Webenix!"
        PageBannerContent="Webenix was founded in the year 2018 with a clear vision in mind of providing the best to our customers. Not only do we firmly believe in serving our best work but we make sure to always respect our customer’s time by immediate responses with the solutions globally accommodating time zone. Meeting the expectations of our customers, they will always have the best customer experience." 
        PageBannerBtnText="Know More"
        PageBannerBtnLink=""
        PageBannerImageWidth="600px"
        PageBannerImageHeight="495px"
        PageBannerImage="/images/pagebg-about.svg"/>
      <SectionIntro 
          IntroSubTitle="Work Offshore to"
          IntroMainTitle="Find Everything Under One Roof At WEBENIX."
          IntroContent='
            <h3>Lorem Ipsum</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
            <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
      '/>
      <MoreResource/>
      <WhyUs/>
      <HireServies/>
      <Blog/>
      </>
  )
}

export default About